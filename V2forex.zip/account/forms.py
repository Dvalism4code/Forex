from django import forms
from account.models import Deposit, Withdraw




class UserDepositForm(forms.ModelForm):
    select_asset = [('', 'Choose Asset'), ('BTC', 'BTC'), ('USDT','USDT')]
    asset = forms.ChoiceField(choices=select_asset, widget=forms.Select(attrs={'id': 'select_input', 'placeholder': 'Select Asset'}))
    deposit_amount = forms.DecimalField(widget=forms.NumberInput(attrs={'id': 'input_amount', 'inputmode': 'decimal'}), max_digits=20, decimal_places=2)


    class Meta:
        model = Deposit
        fields = ['asset', 'deposit_amount']
    

class SetWithdrawalPINForm(forms.Form):
    new_pin = forms.CharField(widget=forms.PasswordInput(attrs={'id': 'pin', 'placeholder': 'Enter 4 digit number ',  'pattern': '\d{6}', 'inputmode': 'numeric'}), min_length=6, max_length=6)
    confirm_pin = forms.CharField(widget=forms.PasswordInput(attrs={'id': 'confirm_pin', 'placeholder': 'Enter 4 digit number',  'pattern': '\d{6}', 'inputmode': 'numeric'}), min_length=6, max_length=6)

    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get('new_pin') != cleaned_data.get('confirm_pin'):
            raise forms.ValidationError("PINs do not match")
        return cleaned_data





withdrawal_type = [('', 'Withdraw Method'), ('BTC', 'Bitcoin'), ('ETH', 'Etherum'), ('USDT', 'USDT'), ('Bank', 'Bank')]

class WithdrawalForm(forms.ModelForm):
   
    pin = forms.CharField(widget=forms.PasswordInput(attrs={'id': 'pin', 'pattern': '\d{6}', 'inputmode':'numeric'}), min_length=6, max_length=6)
    withdraw_amount = forms.DecimalField(widget=forms.NumberInput(attrs={'id': 'amount', 'placeholder': 'Enter Amount', 'pattern': '\d{20}', 'inputmode':'numeric'}), max_digits=20, decimal_places=2)
    select_withdraw_method = forms.ChoiceField(choices=withdrawal_type,  widget=forms.Select(attrs={'id': 'select_input', 'placeholder': 'Select Withdrawal Type'}))
    withdraw_address = forms.CharField(widget=forms.TextInput(attrs={'id': 'address', 'placeholder':'Enter Wallet Address'}), max_length=256)
    bank_name = forms.CharField(widget=forms.TextInput(attrs={'id': 'bank_name', 'placeholder':'Enter Bank Name'}), max_length=100)
    bank_account_number = forms.CharField(widget=forms.NumberInput(attrs={'id': 'bank_account', 'placeholder': 'Enter Bank Account Number'}), max_length=20)
    swift_code = forms.CharField(widget=forms.TextInput(attrs={'id':'swift_code', 'placeholder':'Enter Bank Swift Code', 'maxlength': '11'}), max_length=11)


    class Meta:

        model = Withdraw
        fields = ['select_withdraw_method', 
                  'withdraw_amount', 
                  'withdraw_address', 'bank_name', 'bank_account_number', 'swift_code', 'pin']
