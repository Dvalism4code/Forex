from django.shortcuts import render, redirect
from account.models import Account, Deposit, Withdraw
from account.forms import UserDepositForm, WithdrawalForm, SetWithdrawalPINForm
from django.contrib import messages




def dashboard(request):
    if request.user.is_authenticated:
        account = Account.objects.get(user=request.user)
        return render(request, 'account/users/dashboard.html', {'account': account})
    
    else:
        if not request.user.is_authenticated:

            return redirect('login')
    

def deposit(request):
    if request.user.is_authenticated:
        user = Account.objects.get(user=request.user)
        address = {
            'bitcoin': 'bc1q6nvmc3qh9625xl3ds0dfh4envpnuftf0kczpj2',
            'usdt': '0xe79d89a4074A69f28d3d22290aA2e260FE97d352',
        }

        if request.method == 'POST':
            form = UserDepositForm(request.POST)
            if form.is_valid():
                asset = form.cleaned_data.get('asset')
                deposit_amount = form.cleaned_data.get('deposit_amount')
                if asset == 'BTC':
                    btc_address = address['bitcoin']
                    deposit_fund = Deposit.objects.create(asset=asset, amount=deposit_amount, deposit_address=btc_address, account=user)
                    deposit_fund.save()
                    return redirect('dashboard')
                elif asset == 'USDT':
                    usdt_address = address['usdt']
                deposit_fund = Deposit.objects.create(asset=asset, amount=deposit_amount, deposit_address=usdt_address, account=user)
                deposit_fund.save()
                return redirect('dashboard')
                
        
        else:
            form = UserDepositForm()
            context = {
                'form': form,
                'address': address,
            }
            print(form)
        return render(request, 'account/users/deposit.html', context)
    
    else:
        if not request.user.is_authenticated:

            return redirect('login')
        

def withdraw_funds(request):
    if not request.user.is_authenticated:
        return redirect('login')
    
    account = Account.objects.get(user=request.user)
    
    if account.pin_set is False and not account.withdrawal_pin:
        return redirect('set_withdrawal_pin')

    if request.method == 'POST':
        form = WithdrawalForm(request.POST)
        if form.is_valid():
            withdraw_method = form.cleaned_data.get('select_withdraw_method')
            withdraw_amount = form.cleaned_data.get('withdraw_amount')
            withdraw_address = form.cleaned_data.get('withdraw_address')
            bank_name = form.cleaned_data.get('bank_name')
            bank_account_number = form.cleaned_data.get('bank_account_number')
            swift_code = form.cleaned_data.get('swift_code')
            pin = form.cleaned_data.get('pin')

            if not account.check_withdrawal_pin(pin):
                messages.error(request, "Incorrect PIN")
                return redirect('withdraw_funds')

            if withdraw_amount > account.balance:
                messages.error(request, "Insufficient balance")
                return redirect('withdraw_funds')

            if withdraw_method == 'Bank':
                withdrawal = Withdraw.objects.create(
                    account=account,
                    amount=withdraw_amount,
                    method=withdraw_method,
                    bank_name=bank_name,
                    bank_account_number=bank_account_number,
                   swift_code=swift_code,
                    withdraw_address='N/A'
                )
            else:
                withdrawal = Withdraw.objects.create(
                    account=account,
                    amount=withdraw_amount,
                    method=withdraw_method,
                    withdraw_address=withdraw_address
                )

            # Deduct the amount from user's account balance
            account.balance -= withdraw_amount
            account.save()

            withdrawal.save()
            messages.success(request, "Withdrawal request submitted successfully")
            return redirect('dashboard')
    else:
        form = WithdrawalForm()
    return render(request, 'account/users/withdraw.html', {'form': form, 'account': account})




def set_withdrawal_pin(request):
    if not request.user.is_authenticated:
        return redirect('set_withdrawal_pin')
    
    account = Account.objects.get(user=request.user)
    
    if request.method == 'POST':
        form = SetWithdrawalPINForm(request.POST)
        if form.is_valid():
            new_pin = form.cleaned_data.get('new_pin')
            confirm_pin = form.cleaned_data.get('confirm_pin')
            if new_pin != confirm_pin:
                messages.error(request, "PINs do not match")
                return redirect('set_withdrawal_pin')
            account.set_withdrawal_pin(new_pin)
            messages.success(request, "Withdrawal PIN set successfully")
            return redirect('dashboard')
    else:
        form = SetWithdrawalPINForm()

    return render(request, 'account/users/set_withdraw_pin.html', {'form': form})