from django.shortcuts import render, redirect
from users.forms import UserRegistrationForm, UserAuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages



def RegisterView(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            messages.success(request, f"Hello {username}, you're account have been created !")
            form.save()
            return redirect('login')
    
    else:
        form = UserRegistrationForm()
    context = {'form': form}
    return render(request, 'users/pages/register.html', context)


def UserLoginView(request):
    if request.method == 'POST':
        form = UserAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            # Authenticate user
            user = authenticate(request, username=username, password=password)
            # login the user
            if user is not None:
                login(request, user)
                return redirect('dashboard')
    
    else:
        form = UserAuthenticationForm()
    return render(request, 'users/pages/login.html', {'form': form})



def logout_view(request):
    logout(request)
    return redirect('login')









